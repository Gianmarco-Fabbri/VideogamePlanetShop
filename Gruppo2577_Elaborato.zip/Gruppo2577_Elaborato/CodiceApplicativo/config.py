DB_CONFIG = {
    'host': '127.0.0.1',
    'database': 'GameUniverse',
    'user': 'root',
    'password': ''
}