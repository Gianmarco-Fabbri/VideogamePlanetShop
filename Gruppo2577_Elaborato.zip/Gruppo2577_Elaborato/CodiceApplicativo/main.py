from gui.login import LoginWindow

if __name__ == "__main__":
    VideogamePlanetShop = LoginWindow()
    VideogamePlanetShop.mainloop()